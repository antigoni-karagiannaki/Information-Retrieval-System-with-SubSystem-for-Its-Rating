-----------------------------------------
for monday:
-----------------------------------------

  ## POSTING FILE creation

1) make a **raf Voc**
2) write the content of the Vocabulary file into the **raf Voc**. 

3) read from the **raf Voc** , each term 
  4) get the term's *vocabulary list* and its *Doc_TF*
  5) make a **raf Post**
  6) write each doc_id of the vocabulary list in a line of the **raf Post**
  7) next to it add its tf
  8) next to it add its pos

  9) next to it add the offset/doc number == right line of the DocumentFile.txt 
